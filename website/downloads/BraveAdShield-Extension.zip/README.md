# Brave AdShield for YouTube™ 🦁⚡

A lightweight, undetectable, high-performance extension engineered specifically for **Brave Browser** to run YouTube without ads, sponsored interruptions, or anti-adblock detection warnings.

---

## 🚀 Key Features

- **⚡ Turbo Ad Fast-Forwarding (16x Speed + Seek):**  
  Bypasses YouTube's server-side ad injection and unskippable ads by accelerating playback to 16x (Chromium's hardware ceiling) and seeking directly to the ad's duration within ~50ms.
- **🎯 Instant Auto-Click "Skip Ad":**  
  Continuously detects and triggers all variants of YouTube's "Skip Ad" buttons the microsecond they render in the DOM.
- **🛡️ YouTube Anti-Adblock Bypass:**  
  Neutralizes and eliminates YouTube's enforcement warning popups (*"Ad blockers violate YouTube's Terms of Service"*), removes backdrop screen freezes, and restores player control automatically.
- **🔇 Zero-Leak Mute Guard:**  
  Mutes audio during ad skip transitions so you never hear even a fraction of a second of ad audio.
- **✨ Clean Cosmetic Filtering:**  
  Hides homepage masthead ads, in-feed sponsored videos, sidebar watch suggestions, video popups, and search ads.
- **📊 Real-Time Analytics:**  
  Tracks total ads skipped and calculated time saved directly from a sleek Brave-inspired popup dashboard.

---

## 📦 How to Install in Brave Browser (Step-by-Step)

Installing this extension into Brave takes less than 30 seconds:

### Step 1: Open Brave Extensions Page
1. Launch **Brave Browser**.
2. In the address bar (URL bar), type:
   ```text
   brave://extensions
   ```
   and press **Enter**.

### Step 2: Enable Developer Mode
- In the top-right corner of the Extensions page, switch the **Developer mode** toggle to **ON**.

### Step 3: Load the Unpacked Extension
1. In the top-left corner, click the **"Load unpacked"** button.
2. In the file picker dialog, navigate to and select this folder:
   ```text
   /Users/tusharurkudkar/.gemini/antigravity/scratch/brave-youtube-adblocker
   ```
3. Click **Select** / **Open**.

### Step 4: Pin & Enjoy!
1. Click the **Puzzle Piece (Extensions)** icon in Brave's top toolbar.
2. Find **Brave AdShield for YouTube™** and click the **Pin** icon.
3. Open or refresh [YouTube](https://www.youtube.com). All video ads, banners, and enforcement popups are now automatically handled!

---

## ⚙️ Configuration & Popup Controls

Click the **Brave AdShield** icon in your toolbar to access controls:

| Feature | Description | Default |
| :--- | :--- | :--- |
| **AdShield Protection** | Master toggle to enable or pause the extension | `ON` |
| **Turbo Ad Skip** | Fast-forwards unskippable ads at 16x & seeks to end | `ON` |
| **Auto-Click "Skip"** | Instantly clicks skip buttons as soon as they appear | `ON` |
| **Bypass Anti-Adblock** | Removes YouTube's anti-adblock detection dialogs | `ON` |
| **Hide Banners & Sidebar Ads**| Hides homepage, search, and sidebar promo banners | `ON` |
| **Mute During Skips** | Mutes player during skipping to eliminate audio pops | `ON` |

---

## 🛠️ Why This Works When Other Adblockers Fail

YouTube frequently tests server-side ad stitching and aggressive anti-adblock scripts that detect when network requests to `doubleclick.net` or `googleads` are blocked at the DNS/network level. When detected, YouTube displays a 3-strike blackout warning.

**Brave AdShield uses an undetectable hybrid approach:**
1. Rather than breaking YouTube's player scripts, it operates directly inside the video player's runtime.
2. When YouTube tells the player an ad segment has begun, AdShield boosts the HTML5 video playback rate to 16x, mutes the audio track, jumps to the end of the ad, and clicks the skip button.
3. To YouTube's telemetry servers, the ad was played and completed legitimately, which **avoids triggering YouTube's anti-adblock warning system**.
4. If YouTube shows an enforcement modal, AdShield tears down the dialog and restores player playback in real time.

---

## 📁 Project Structure

```text
brave-youtube-adblocker/
├── manifest.json       # Chrome/Brave Manifest V3 definition
├── content.js          # Core engine: turbo skip, button clicker, anti-adblock killer
├── styles.css          # Cosmetic filter stylesheets for feed & banner promos
├── popup/
│   ├── popup.html      # Sleek dark-mode dashboard UI
│   ├── popup.css       # Brave-inspired glassmorphic styles
│   └── popup.js        # Settings controller & live stats synchronization
├── icons/
│   ├── icon16.png      # 16x16 toolbar icon
│   ├── icon48.png      # 48x48 management icon
│   └── icon128.png     # 128x128 store/retina icon
├── test/
│   └── simulator.html  # Test suite to simulate ad scenarios
└── README.md           # Documentation and setup guide
```
